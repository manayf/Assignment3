package defaultPackage;
import java.util.Scanner;
public class Course {
	
	private String courseID;
	private String courseName;
	private String instructorName;
	private int credits;
	
	
	
	//Class constructor
	
	public Course(String cID, String courseN, String instructor, int myCredits) {
		
		courseID = cID;
		courseName = courseN;
		instructorName = instructor;
		credits = myCredits; 
		
		
	}
	
	
	//Accessors
	
	public String getCourseID() {
		
		return courseID;
	}
	public String getCourse() {
		
		return courseName;
	}
	public String getInstructor() {
	
		return instructorName;
	}
	public int getCredits() {
	
		return credits;
	}
	
	
	
	
	//Mutators
	
	public void setCourseID(String cID) {
		
		courseID = cID;
	}
	public void setCourse(String course) {
		
		courseName = course;
	}
	public void setInstructor(String instructor) {
	
		instructorName = instructor;
	}
	public void setCredits(int myCredits) {
	
		credits = myCredits;
	}
}
	
	
	 

	
	
	
