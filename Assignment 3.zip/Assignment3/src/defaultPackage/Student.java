package defaultPackage;
import java.io.*;
import java.util.*;
public class Student implements Serializable {
	
	public String studentID;
	public String name;
	public String major;
	public int age;
	public ArrayList<Double> grades; 
	public ArrayList<Course> listOfCourses;
	
	//Constructor for student class
	
	public Student(String sID, String myName, int myAge, String myMajor, ArrayList<Double> myGrades) {
		
		
		
			studentID = sID;
			name = myName; 
			major = myMajor;
			age = myAge;
			
			
			for (Double grade : myGrades) {
			if (grade <1 || grade >100) {
				throw new IllegalArgumentException("Please enter a grade between 1-100");
			}
			grades = myGrades;
			listOfCourses = new ArrayList<>();
			
			}	
	}  
	
	
	
	
	
	//Accessors
	
	public String getStudentId() {
		
		return studentID;
	}

    public String getStudentName() {
	
    	return name;
}

    public String getMajor() {
	
    	return major;
}

    public int getAge() {
	
    	return age;
}
    
    
    public String getGrades() {
    	
    	return grades.toString();
    }
    
    
    
    
    
    
    //Mutators
    
public void setStudentID(String sID) {
    	
    	studentID = sID;
    }
public void setName(String sName) {
	
	name = sName;
}
public void setMajor(String myMajor) {
	
	major = myMajor;
}
public void setAge(int myAge) {
	
	age = myAge;
}
public void setGrades(ArrayList<Double> myGrades) {
	
	grades = myGrades;
}
    
    
 public void assignStudentCourses(Course sCourse) {
	 listOfCourses.add(sCourse);
	 
 }
    
 
 
 
 
 
 
 
 
 
 //To String Method
 
 //@Override
 
	 
	 
	 public String toString() {
		    return "Student ID: " + studentID + ", Name: " + name + ", Age: " + age + ", Major: " + major + ", Grades: " + grades.toString();
	 
 }
 
 
 
 
 
 
 








}
    
    
    
    
    
    
	
	
	