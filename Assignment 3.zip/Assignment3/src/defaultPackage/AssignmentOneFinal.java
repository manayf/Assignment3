package defaultPackage;

import java.io.*;
import java.util.*;
import java.util.ArrayList;

import java.util.Scanner;



public class AssignmentOneFinal {
	
	
	public static ArrayList<Student> students = new ArrayList<>(0);
	private static ArrayList<Course> courses = new ArrayList<>(0);


	


	public static void main(String[] args) throws Exception {

		// TODO Auto-generated method stub



				//create a scanner object
				Scanner keyboard = new Scanner(System.in);

				

				



				
		        //Create a variable to help stop the while loop
		        boolean loop = true;
		        
		  

		        while (loop) {

		            System.out.println("\n1. Add Student");

		            System.out.println("2. Add Course");
		            		           
		            System.out.println("3. Assign Course ");

		            System.out.println("4. Assign Grade");
		            
		            System.out.println("5. List of Students");
		            
		            System.out.println("6. Save Data");
		            
		            System.out.println("7. Load Data");

		            System.out.println("8. Exit");

		            System.out.println("Choose an option: ");

		            int choice = keyboard.nextInt();

		



		            switch (choice) {

		                case 1:

		                   addStudent();
		                
		                   
		                    break;
		            

		                case 2: 

		                   addCourse();
		                   
		                   	break;
		                
		                   	
		                case 3:
		                	
		                	assignCourse();
		                	
		                	
		                	break;
		                	
		                	
		                case 4: 
		                	
		                	assignStudentGrade();
		                	break; 
		                	
		                case 5:
		                	
		                	for (Student student : students) {
		                	    System.out.println(student.toString());
		                	    System.out.println();
		                	}
		                    break;
		                    
		                    
		                case 6: 
		                	
		                	createFile();
		                	
		                	break;
		                	
		                	
		                case 7: 
		                	
		                	loadStudentsFromFile("C:\\Users\\jaket\\OneDrive\\Desktop\\students_data.txt");
		                	
		                	break;
		                
		                case 8: 
		                	System.out.println("Goodbye");
		                	loop = false;
		                	
		                	break; 
		                	
		                default:
		            }
		                	
		        }
		                
		                	

		            


		        

		    }
		            //Creating a student object
		            private static void addStudent() throws DuplicateIDException{ 
		            	Scanner keyboard = new Scanner(System.in);
		            	
		            	System.out.println("Would you like to input a 1: Graduate Student "
		            			+ "or 2:  Undergraduate Student." + "\n *** Press 1 or 2 ***");
		            	
		            	int graduate = keyboard.nextInt();
		            	
		            	if (graduate == 1) {
		            		
		            		assignGraduateStudent(); //Method at bottom
		            	}else if (graduate == 2) {
		            		
		            		assignUndergrad();
		            	}
		            }

		            	
		            	
		            	
		           
		               
						
						
		            
		            
		            //Creating a course object 
		            private static void addCourse() {
		            	Scanner keyboard = new Scanner(System.in);
		            	
		            	 System.out.print("Enter Course ID: ");
			                String courseID = keyboard.nextLine();
			                
			                System.out.println();
			                
			                System.out.print("Enter Course Name: ");
			                String courseName = keyboard.nextLine();
			                
			                System.out.println();
			                
			                System.out.print("Enter Instructor Name: ");
			                String  instructorName = keyboard.nextLine();
			                
			                System.out.println();
			                
			                System.out.print("Enter Class Credit Hours: ");
			                int  credits = keyboard.nextInt();
		            
			                System.out.println();
			                
			                Course course = new Course(courseID, courseName, instructorName, credits);
			                courses.add(course);
			                System.out.println("Course Added.");
		            }

		     
		            	
		      
		            			
		            			// ASSIGN COURSE METHOD

				            public static void assignCourse() {

				            	Scanner keyboard = new Scanner(System.in);

				            	

				            	System.out.println("What is the name of the student you would like to assign a course to?");

				            	String sName = keyboard.nextLine();

				            	System.out.println("What course would you like to assign to " + sName);

				            	String cName = keyboard.nextLine();



				                Student student = locateStudent(sName);

				                Course course = locateCourse(cName);				             				                
				             	assignStudentGrade();		               

				                if (student != null && course != null) {

				                    student.assignStudentCourses(course);

				                    System.out.println(cName + " assigned to " + sName + "with grade assi " );

				                } else {

				                    System.out.println("Invalid Entry.");
				                    
				                    

				                }

				            }
				        				            
				        
				            
				            
				            
				            
				            public static Student locateSID(String sID) {
				            	
				            	for (Student student : students) {
				            		if (student.getStudentId().equals(sID)) {
				            			return student;
				            		}
				            	}
								return null;
				            }

				            //This is a method that will be used to match user input to locate Matching Student

				            public static Student locateStudent(String sName) {

				            	//For Loop that scans the array of Students for the matching Student name

				                for (Student student : students) {

				                    if (student.getStudentName().equals(sName)) {

				                        return student;

				        

				                    }

				                }

				            
				               return null;
				             

				            }

				            				       				            

				            //This is a method that will be used to match user input to locate Matching Course

				               private static Course locateCourse(String cName) {		        	   	            

				             

				            	   for (Course course : courses) {           //For Loop that scans the array of courses for the matching course name

				            		   if(course.getCourse().equals(cName)) {

				            			   return course; 

				        		   }

				        	   }

				        	   

				           return null;
		            
		            
		            
}
		        
				               public void assignStudentGrade() {
				            	  Scanner keyboard = new Scanner(System.in);
				            	  				            	   				            	   				         	   
				            	  ArrayList<Double> grade = new ArrayList<>();
				            	   

				            	  System.out.println("What grade would you like to enter for the course?:  ");
				            	   
				            	  double inputGrade = keyboard.nextDouble();
				            	  
				            	  grade.add(inputGrade);	
				            	  
				            	  Student.setGrades(grade);
				            		   
				            	   }
				            	   
				            	   
				            //GRADUATE STUDENT METHOD	 
				               
				            public static void assignGraduateStudent() {
				            	System.out.print("Enter student ID in the form of ABC123: ");
				                Scanner keyboard = new Scanner(System.in);
				                //Get Graduate Student ID
				                String sID = keyboard.nextLine();
				                				              				              				                				                				                				          				          				                
				                System.out.println();
				                
				                //Get Graduate Student Name
				                System.out.print("Enter student name: ");
				                String myName = keyboard.nextLine();
				                
				                System.out.println();
				                
				                //Get Graduate Student Major
				                System.out.print("Enter student major: ");
				                String  myMajor = keyboard.nextLine();
				                
				                System.out.println();
				                
				                //Get Graduate Student age
				                System.out.print("Enter student age: ");
				                int  myAge = keyboard.nextInt();
				                 				          
				                System.out.println();
				                
				                //Get Graduate Student Grade
				                System.out.print("Enter Student Grade: ");
				                int myGrades = keyboard.nextInt();
				                keyboard.nextLine();
				                System.out.println();
				                
				                //Get Graduate Student Advisor Name
				                
				                System.out.println("Enter Grad Student Advisor Name: ");
				                String advisorName = keyboard.nextLine();
				                
				               
				                
				                //Get Graduate Student Thesis Title
				                System.out.println("Enter Student Thesis Title: ");
				                String thesisTitle = keyboard.nextLine();
				                
				                System.out.println();
				                
				                try {
					                for (Student student : students) {
					                	if (student.getStudentId().equals(sID)) {
						                	throw new DuplicateIDException("There is already a student with this Student ID number");
					                	}
					                }
				                }
					                
				                
					                
					                	
					                catch (DuplicateIDException e) {
					                	System.out.println(e.getMessage());
					                	
					                	
					                }   
					                
					                finally {
					                	
					                }
				                GraduateStudent gradStudent = new GraduateStudent(advisorName,  thesisTitle, sID,  myName, myMajor,  myAge,  myGrades);
				                students.add(gradStudent);
				            }
				               
				               
				               
				               // NOW CREATE A METHOD TO ADD AN UNDERGRADUATE STUDENT
				            
				            public static void assignUndergrad() {
				            	
				            	System.out.print("Enter student ID in the form of ABC123: ");
				                Scanner keyboard = new Scanner(System.in);
				                //Get UnderGraduate Student ID
				                String sID = keyboard.nextLine();
				                				              				              				                				                				                				          				          				                
				                System.out.println();
				                
				                //Get UnderGraduate Student Name
				                System.out.print("Enter student name: ");
				                String myName = keyboard.nextLine();
				                
				                System.out.println();
				                
				                //Get UnderGraduate Student Major
				                System.out.print("Enter student major: ");
				                String  myMajor = keyboard.nextLine();
				                
				                System.out.println();
				                
				                //Get UnderGraduate Student age
				                System.out.print("Enter student age: ");
				                int  myAge = keyboard.nextInt();
				                 				          
				                System.out.println();
				                
				                //Get UnderGraduate Student Grade
				                System.out.print("Enter Student Grade: ");
				                int myGrades = keyboard.nextInt();
				                keyboard.nextLine();
				                System.out.println();
				                
				              
				                //Get UnderGraduate Student minor
				                
				                System.out.println("Enter Student Minor Name: type NONE if no minor: \n");
				                
				                String minor = keyboard.nextLine();
				                
				                if (minor == "NONE") {
				                	minor = null;
				                }
				                
				                
				                
				                //Get UnderGraduate Student College Year
				                System.out.println("Enter Student College Year:  1 for Freshman - 2 for Sophomore - 3 for Junior - 4 for Senior: ");
				                int yrsOfStudy = keyboard.nextInt();
				                
				                System.out.println();
				            	
				                
				                //Enter a Try/Catch block to catch Duplicate ID
				                try {
					                for (Student student : students) {
					                	if (student.getStudentId().equals(sID)) {
						                	throw new DuplicateIDException("There is already a student with this Student ID number");
					                	}
					                }
				                }
					                
				                
					                
					                	
					                catch (DuplicateIDException e) {
					                	System.out.println(e.getMessage());
					                	
					                	
					                }   
					                
					                finally {
					                	
					                }
				            	
				            	UnderGraduate underGrad = new UnderGraduate( yrsOfStudy,minor ,sID, myName, myMajor, myAge, myGrades );
				            	students.add(underGrad);
				            	
				            	
				            }
				               
				               
				             //WRITE TO A FILE METHOD  
				            public static void createFile()  {

                                try {

                                  FileOutputStream myStudentData = new FileOutputStream("StudentSystem.dat");
                                  ObjectOutputStream outputStudentData = new ObjectOutputStream(myStudentData);
                                  
                                  
                                 for (Student student: students)  {
                                	 
                                    outputStudentData.writeObject(student);

                                 
                                  }
                                 
                                 System.out.println("Data Written to File Successfully");
                                 
                                 

                                } catch (IOException e) {

                                  System.out.println("An error occurred.");

                                  e.printStackTrace();

                                }

                              }
				            
				            
				            
				            
				            
				            
				            
				            //READ FROM A FILE METHOD (LOAD)

                              public static void readFile() throws ClassNotFoundException {

                                try {
                                	Scanner keyboard = new Scanner(System.in);
                                	System.out.println("\nPlease enter the name of the file you would like to load in:");
                                	
                                	String fileSearch = keyboard.nextLine();
                              
                                  FileInputStream studentFile = new FileInputStream(fileSearch);
                                  ObjectInputStream objectInputFile = new ObjectInputStream(studentFile);

                                  for (Student student : students) {
                                	  objectInputFile.readObject(); 
                                	  System.out.println();
                                	  
                                	  
                                  }
                                  System.out.println("Successfully Read the file.");
                                  objectInputFile.close();
                                  
                                  for (Student student : students) {
                                	  System.out.println();
                                	  System.out.println(student.toString());
                                  }
                                  
                                  
                                  
                                 
                                } catch (Exception e) {

                                  System.out.println("An error occurred.");

                                  e.printStackTrace();

                                }

                              }

                              
                              
                                






                               
				            
	//**************************************************************************			            
				            
	// Assignment 3 work  (  Binary Search method,  Load file data,  Sorting Algorithm(Merge)	)		            



		public static int binarySearch(int[] array, int sID) {
			int first = 0;   //First position of array
			int last = array.length - 1; //Last position (remember the minus 1 since index starts at 0
			int position = -1;		
			boolean found = false; //Used to flag the search for value
						
			// statements to identify position
								
			//Use while loop to continue 
			
			while(first <= last) {
				int middle = (first + last)/2;  //Finds the middle position index of current array
				
			
			if (array[middle] == sID) {
				found = true;
				position = middle;
								
			}
			else if (array[middle] > sID) {   // used if the value is in lower half
				last = middle-1; 
							
			}
			else 
				first = middle + 1;
																		
		}
			return position;

		}		
				            
				            
				            
				            
				            
				            
				            
				            
				            
				            
	//***************************************************************************
		
		public static void loadStudentsFromFile(String fileName) throws FileNotFoundException {
			Scanner keyboard = new Scanner(System.in);
			
			//System.out.println("Please enter the full file path for the file to upload: ");
			
			int lineNumber = 0;
			
			//"C:\\Users\\jaket\\OneDrive\\Desktop\\students_data.txt"			
			File fileStudents = new File(fileName);
			
			Scanner scan = new Scanner(fileStudents);
			
			//Continues to read the next line and parse the information into variables
			while(scan.hasNextLine()) {
				lineNumber++;
				String studentLine = scan.nextLine();
				
				
				System.out.println("Reading line " + lineNumber + ": " + studentLine);
				String[] studentInfo = studentLine.split(","); //This is used to separate each student into its own array to manipulate
				
				
				//This if statement will place each field into a variable to create an object later
				if (studentInfo.length == 5) {
					String studentID = studentInfo[0];
					String name = studentInfo[1];
					int age = Integer.parseInt(studentInfo[2]);
					String major = studentInfo[3];
					
					
				//Grades need to be split and put into an array list
				String[] gradeGPA = studentInfo[4].split(";");
				ArrayList<Double> grades = new ArrayList<>();
				
				
				
				
				
				try {	
				
				for (String grade : gradeGPA) {
					grades.add(Double.parseDouble(grade.trim()));
					
				
				}
				} catch (NumberFormatException e) {
					
					System.out.println("Error Parsing Grades for student: " + studentID);
					e.printStackTrace();
					
					
					
					
					
				}
					Student student = new Student(studentID, name, age, major, grades);
					
					students.add(student);
					
				}else {
					System.out.println("Incorrect Data Formatting" + studentLine);
					
				}
																			
			}
			
			scan.close();
			System.out.println("Student data upload complete!");
			
		//STILL NEEDS MORE WORK!!	
			

		}

	

			
		
				            
				            
		}		            
				            
		
		
				            
/*			//Instantiating 2 course objects

Course calculus3 = new Course("MATH3351", "Calculus3", "Meow", 4);

Course pf3 = new Course("COSC2436", "PF3", "Cook", 4);



//Instantiating 2 student objects

Student Amana = new Student("a123", "Amana", 20, "CompSci", 3.5);

Student Jake = new Student("j234", "Jake", "CompSci", 20, 100);



//Add instantiated student objects in student array

students.add(Jake);

students.add(Amana);

//Add instantiated course objects in course array

courses.add(calculus3);

courses.add(pf3);
	            
				            
*/				            
				            
				            	   
				            	
				            		
				            	
				            	   
				            	   
				            	   
				               
	
				            	   
		        
						
		        

		        

		        

		        

		        

		        

		        

	

	

	

	

	

	

		

		

		

		

		

	