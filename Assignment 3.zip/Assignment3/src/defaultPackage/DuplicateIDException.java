package defaultPackage;

public class DuplicateIDException extends Exception{

	public DuplicateIDException(String message) {
		super(message);
	}
	
}
