package defaultPackage;

import java.util.ArrayList;

public class UnderGraduate extends Student {
	private  int yearsOfStudy;
	private  String minor = "";
	
	
	public UnderGraduate(int yrsOfStudy, String m,String sID, String myName,String myMajor, int myAge, int myGrades ) {
		super(sID,myName, myMajor, myAge, myGrades);
		yearsOfStudy = yrsOfStudy;
		minor = m;
		
		
	}
	//Accessors
	public int getYearsOfStudy() {
		return yearsOfStudy;
		
	}
	
	public String getMinor() {
		return minor;
	}	
		//Mutators
		
	public void  setYearsOfStudy(int yrs) {
		yearsOfStudy = yrs;
		
	}
	
	
	public void setMinor(String Minor) {
		minor = Minor;
		
	}
	
	
	@Override
	public  String toString() {
		String displayUnderGrad = "UNDERGRADUATE STUDENT:\n " + "Student ID: " + studentID + "    Student Name: " 
				 + name + "    Major: " + major + "    Age: "  + age + "    Grade: "
				 + grades + "    Minor: " + minor + "    College Year: " + yearsOfStudy;
				 
return displayUnderGrad;
	}
}
