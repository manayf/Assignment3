package defaultPackage;

public class GraduateStudent extends Student{

	public  String advisorName;
	public  String thesisTitle;
	
	public GraduateStudent(String aName, String tTitle, String sID, String myName, String myMajor, int myAge, int myGrades) {
			super(sID, myName, myMajor, myAge, myGrades);
			advisorName = aName;
			thesisTitle = tTitle;
	
}
	
	
	
	
	
	//Accessors
	public String getAdvisorName() {
		return advisorName;
		
	}
	
	public String getThesisTitle() {
		return thesisTitle;
	}
	
	
	
	
	
	
	//Mutators
	public void setAdvisorName(String adName) {
		advisorName = adName;
		
	}
	
	
	public void setThesisTitle(String thesis) {
		thesisTitle = thesis;
	}
	
	@Override
	public  String toString() {
		String displayGradStudent = "GRADUATE STUDENT:\n " + "Student ID: " + studentID + "    Student Name: " 
				 + name + "    Major: " + major + "    Age: "  + age + "    Grade: "
				 + grades + "    Advisor Name: " + advisorName + "    Thesis Title: " 
				 + thesisTitle;
return displayGradStudent;
}
}